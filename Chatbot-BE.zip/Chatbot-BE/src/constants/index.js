module.exports = {
  A_WEEK: 7 * 86400 * 1000,
};
